package com.example.hamburgueriaz;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int PRECO_BASE = 20;
    private static final int PRECO_BACON = 2;
    private static final int PRECO_QUEIJO = 2;
    private static final int PRECO_ONION_RINGS = 3;

    private int quantidade = 0;

    private EditText editNome;
    private CheckBox checkBacon, checkQueijo, checkOnionRings;
    private TextView textQuantidade, textResumo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editNome = findViewById(R.id.editNome);
        checkBacon = findViewById(R.id.checkBacon);
        checkQueijo = findViewById(R.id.checkQueijo);
        checkOnionRings = findViewById(R.id.checkOnionRings);
        textQuantidade = findViewById(R.id.textQuantidade);
        textResumo = findViewById(R.id.textResumo);
    }

    // Etapa 5: botão "+"
    public void somar(View view) {
        quantidade++;
        atualizarQuantidade();
    }

    // Etapa 5: botão "-" (nunca abaixo de zero)
    public void subtrair(View view) {
        if (quantidade > 0) {
            quantidade--;
        }
        atualizarQuantidade();
    }

    private void atualizarQuantidade() {
        textQuantidade.setText(String.valueOf(quantidade));
    }

    // Etapa 6: cálculo do valor total
    private int calcularPreco(boolean temBacon, boolean temQueijo, boolean temOnionRings) {
        int precoUnitario = PRECO_BASE;
        if (temBacon) precoUnitario += PRECO_BACON;
        if (temQueijo) precoUnitario += PRECO_QUEIJO;
        if (temOnionRings) precoUnitario += PRECO_ONION_RINGS;
        return precoUnitario * quantidade;
    }

    private String simNao(boolean valor) {
        return valor ? "Sim" : "Não";
    }

    // Etapas 6 e 7: monta o resumo e envia por e-mail via Intent
    public void enviarPedido(View view) {
        String nome = editNome.getText().toString().trim();
        boolean temBacon = checkBacon.isChecked();
        boolean temQueijo = checkQueijo.isChecked();
        boolean temOnionRings = checkOnionRings.isChecked();

        if (nome.isEmpty()) {
            Toast.makeText(this, "Informe o seu nome", Toast.LENGTH_SHORT).show();
            return;
        }
        if (quantidade == 0) {
            Toast.makeText(this, "Escolha pelo menos 1 hambúrguer", Toast.LENGTH_SHORT).show();
            return;
        }

        int precoFinal = calcularPreco(temBacon, temQueijo, temOnionRings);

        String mensagem = "Nome do cliente: " + nome + "\n"
                + "Tem Bacon? " + simNao(temBacon) + "\n"
                + "Tem Queijo? " + simNao(temQueijo) + "\n"
                + "Tem Onion Rings? " + simNao(temOnionRings) + "\n"
                + "Quantidade: " + quantidade + "\n"
                + "Preço final: R$ " + precoFinal;

        textResumo.setText(mensagem);

        String assunto = "Pedido de " + nome;

        Intent intent = new Intent(Intent.ACTION_SENDTO);
        // assunto e corpo também na URI: alguns apps de e-mail ignoram os extras com ACTION_SENDTO
        intent.setData(Uri.parse("mailto:?subject=" + Uri.encode(assunto)
                + "&body=" + Uri.encode(mensagem)));
        intent.putExtra(Intent.EXTRA_SUBJECT, assunto);
        intent.putExtra(Intent.EXTRA_TEXT, mensagem);

        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Nenhum app de e-mail encontrado", Toast.LENGTH_LONG).show();
        }
    }
}
